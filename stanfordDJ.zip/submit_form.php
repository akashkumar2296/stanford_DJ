<?php
// Pear Mail Library
require_once "Mail.php";

$name = $_POST['name']; // required
$email = $_POST['email']; // required
$phoneNumber = $_POST['phoneNumber']
$message = $_POST['message']; // required

$from = '<stanfordapp>';
$to = '<akashkumar2296@gmail.com>';
$subject = 'Booking inquiry';
$body = <<<EOT
        Email: {$email}
        Name: {$name}
        Phone Number: {$phoneNumber}
        Message: {$message}
        EOT;

$headers = array(
    'From' => $from,
    'To' => $to,
    'Subject' => $subject
);

$smtp = Mail::factory('smtp', array(
        'host' => 'ssl://smtp.gmail.com',
        'port' => '465',
        'auth' => true,
        'username' => 'stanforddj2017@gmail.com',
        'password' => 'rajraina'
    ));

$mail = $smtp->send($to, $headers, $body);

if (PEAR::isError($mail)) {
    echo('err');
} else {
    echo('ok');
}
die();
?>
